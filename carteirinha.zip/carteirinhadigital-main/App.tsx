import { NativeBaseProvider } from "native-base";
import React from "react";

import { NavigationContainer } from "@react-navigation/native";
import { AppRoutes } from "./src/routes/app.routes";

export default function App() {
  return (
    <NavigationContainer>
      <NativeBaseProvider>
        <AppRoutes />
      </NativeBaseProvider>
    </NavigationContainer>
  );
}
