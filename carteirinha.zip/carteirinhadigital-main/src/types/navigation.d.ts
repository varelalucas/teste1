export declare global {
  namespace ReactNavigation {
    interface RootParamList {
      home: undefined;
      carteirinha: { matricula: string, id: string, name: string };
      criarcarteirinha: undefined;
    }
  }
}
