import { useNavigation } from "@react-navigation/native";
import { Box, Flex, Heading, IconButton, Text, VStack } from "native-base";
import { CaretRight } from "phosphor-react-native";

interface ICardMatriculaProps {
  matricula: string;
  name: string;
  id: string
}

export function CardMatricula(props: ICardMatriculaProps) {
  const navigation = useNavigation();

  const handleGoToCarteirinha = (matricula: string, nome: string, id: string) => {
    navigation.navigate("carteirinha", { matricula, name: nome, id });
  };

  return (
    <VStack>
      <Box borderLeftWidth={6} borderLeftColor="purple.500" bg="gray.900" p={8}>
        <Flex flexDir="row" alignItems="center" justify="space-between">
          <Box>
            <Heading color="white" size="sm">
              {props.name}
            </Heading>
            <Text color="gray.400" fontSize="xs">
              {props.matricula}
            </Text>
          </Box>
          <IconButton
            onPress={() => handleGoToCarteirinha(props.matricula, props.name, props.id)}
            icon={<CaretRight size={24} color="#fff" />}
          />
        </Flex>
      </Box>
    </VStack>
  );
}
