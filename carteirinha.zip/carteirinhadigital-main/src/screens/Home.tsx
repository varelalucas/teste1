import { useNavigation } from "@react-navigation/native";
import { Box, Flex, Heading, IconButton, Text, VStack } from "native-base";
import { Prohibit } from "phosphor-react-native";
import { useEffect, useState } from "react";

import AsyncStorage from "@react-native-async-storage/async-storage";

import { Plus } from "phosphor-react-native";
import { CardMatricula } from "../components/CardMatricula";

export function Home() {
  const [data, setData] = useState(null);
  const navigation = useNavigation();

  useEffect(() => {
    const fetchData = async () => {
      const data = await AsyncStorage.getItem(
        "carteirinhadigital:carteirinhas"
      );

      const dataJson = JSON.parse(data);

      setData(dataJson);
    };

    fetchData();
  });

  const handleGoToCreateCarteirinha = () => {
    navigation.navigate("criarcarteirinha");
  };

  return (
    <VStack flex={1} bg="gray.800" pb={6}>
      <Box bg="gray.900" py={8} px={5}>
        <Flex flexDir="row" justify={"space-between"} alignItems="center">
          <Heading color="white">Carteirinha Digital</Heading>
          <IconButton
            onPress={() => handleGoToCreateCarteirinha()}
            icon={<Plus size={30} color="#fff" />}
          />
        </Flex>
      </Box>
      <Box mt={10} px={5} width="full">
        <Heading color="white" size="md">
          Suas Carteirinhas
        </Heading>
        <VStack mt={6} width="full" space={4}>
          {data ? (
            data.map((item: any) => {
              return (
                <CardMatricula
                  matricula={item.matricula}
                  name={item.nome}
                  id={item.id}
                  key={item.id}
                />
              );
            })
          ) : (
            <Box mt={16}>
              <Flex alignItems="center">
                <Prohibit size={90} color="#c9c9c9" />
                <Text color="#c9c9c9" textAlign="center">
                  Infelizmente não conseguimos achar nenhuma carteirinha no seu
                  dispositivo, tente criar uma nova!
                </Text>
              </Flex>
            </Box>
          )}
        </VStack>
      </Box>
    </VStack>
  );
}
