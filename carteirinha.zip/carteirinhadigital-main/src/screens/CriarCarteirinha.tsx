import {
  Box,
  Button,
  Flex,
  Heading,
  IconButton,
  Input,
  useToast,
  VStack,
  Text
} from "native-base";
import uuid from "react-native-uuid";

import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from "@react-navigation/native";
import { CaretLeft, Prohibit } from "phosphor-react-native";
import { useEffect, useState } from "react";

export function CriarCarteirinha() {
  const [matricula, setMatricula] = useState("4541290170");
  const [nome, setNome] = useState("Teste");
  const toast = useToast();
  const navigation = useNavigation();

  const [error, setError] = useState(false)

  useEffect(() => {
    const loadData = async () => {
      const response = await AsyncStorage.getItem(
        "carteirinhadigital:carteirinhas"
      );
      const responseData = response ? JSON.parse(response) : [];
  
      if (responseData.length >= 4) {
        setError(true)
      }
    }

    loadData()
  })

  const handleCriarCarteirinha = async () => {
    const newItem = {
      matricula: matricula,
      nome: nome,
      id: uuid.v4(),
    };

    const response = await AsyncStorage.getItem(
      "carteirinhadigital:carteirinhas"
    );
    const responseData = response ? JSON.parse(response) : [];

    if (responseData.length >= 4) {
      setError(true)
    }

    const data = [newItem, ...responseData];

    await AsyncStorage.setItem(
      "carteirinhadigital:carteirinhas",
      JSON.stringify(data)
    );
    toast.show({
      description: "Carteirinha criada com sucesso",
    });
    setTimeout(() => {
      navigation.navigate("home");
    }, 500);
  };

  const handleGoBack = () => {
    navigation.goBack()
  }

  if (error === true) {
    return (
      <VStack flex={1} bg="gray.800" pb={6}>
        <Box bg="gray.900" py={8} px={5}>
          <Flex flexDir="row" justify={"space-between"} alignItems="center">
            <IconButton onPress={handleGoBack} icon={<CaretLeft size={30} color="#fff" />} />
            <Heading color="white">Criar carteirinha</Heading>
          </Flex>
        </Box>
        <Box mt={10} px={5} width="full">
          <VStack mt={6} width="full" space={4}>
              <Box mt={16}>
                <Flex alignItems="center">
                  <Prohibit size={90} color="#c9c9c9" />
                  <Text color="#c9c9c9" textAlign="center">
                    Infelizmente você atingiu o limite máximo de 4 carteirinhas nesse dispositivo!
                  </Text>
                </Flex>
              </Box>
          </VStack>
        </Box>
      </VStack>
    )
  }

  return (
    <VStack flex={1} bg="gray.800">
      <Box bg="gray.900" py={8} px={5}>
        <Flex flexDir="row" justify={"space-between"} alignItems="center">
          <IconButton onPress={handleGoBack} icon={<CaretLeft size={30} color="#fff" />} />
          <Heading color="white">Criar carteirinha</Heading>
        </Flex>
      </Box>
      <Box mt={10} px={5}>
        <Input
          mb={4}
          borderColor="gray.700"
          bg="gray.900"
          size="lg"
          focusOutlineColor="purple.500"
          _focus={{
            backgroundColor: "purple.500.5",
          }}
          _hover={{
            borderColor: "purple.500",
          }}
          placeholder="Nome da carteirinha"
          color="white"
          onChangeText={setNome}
        />
        <Input
          mb={4}
          borderColor="gray.700"
          bg="gray.900"
          size="lg"
          focusOutlineColor="purple.500"
          _focus={{
            backgroundColor: "purple.500.5",
          }}
          _hover={{
            borderColor: "purple.500",
          }}
          placeholder="Sua matrícula"
          color="white"
          onChangeText={setMatricula}
        />
        <Button colorScheme="purple" onPress={handleCriarCarteirinha}>
          Criar
        </Button>
      </Box>
    </VStack>
  );
}
