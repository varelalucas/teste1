import { useNavigation, useRoute } from "@react-navigation/native";
import { useEffect } from "react";
import { Text, VStack, Box, Flex, IconButton, Heading, useToast } from "native-base";

import { CaretLeft, Trash } from 'phosphor-react-native'
import QRCode from "react-native-qrcode-svg";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface IRouteParams {
  matricula: string;
  name: string;
  id: string
}

export function Carteirinha() {
  const route = useRoute()
  const navigation = useNavigation()
  const toast = useToast()

  const { id, matricula, name } = route.params as IRouteParams

  const handleGoBack = () => {
    navigation.goBack()
  }

  const handleDeleteCarteirinha = async (id: string) => {
    const response = await AsyncStorage.getItem(
      "carteirinhadigital:carteirinhas"
    );
    const responseData = response ? JSON.parse(response) : [];

    const newData = responseData.filter((item: { id: string; }) => item.id !== id)

    await AsyncStorage.setItem(
      "carteirinhadigital:carteirinhas",
      JSON.stringify(newData)
    );
    toast.show({
      description: "Carteirinha deletada com sucesso",
    });
    setTimeout(() => {
      navigation.navigate("home");
    }, 500);
  }

  return (
    <VStack flex={1} bg="gray.800">
      <Box bg="gray.900" py={8} px={5}>
        <Flex flexDir="row" justify={"space-between"} alignItems="center">
          <IconButton icon={<CaretLeft size={30} color="#fff" />} onPress={handleGoBack} />
          <Heading color="white">{name}</Heading>
        </Flex>
      </Box>
      <Box px={5} mt={10}>
        <Flex alignItems="center" py={5} bg="white" rounded="sm">
        <QRCode size={300} value={`{"UE":93521,"MatriculaAluno":${matricula},"Ano":2022,"Visitante":0,"Hash":"23b2db47488fc2389a44b5342393f73c"}`} />
        </Flex>
      </Box>
      <Box>
        <Flex alignItems="center" mt={20}>
          <IconButton onPress={() => handleDeleteCarteirinha(id)} icon={<Trash color="#ff3421" size={50} />} />
        </Flex>
      </Box>
    </VStack>
  );
}
