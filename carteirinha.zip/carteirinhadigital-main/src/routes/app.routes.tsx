import { Carteirinha } from "../screens/Carteirinha";
import { Home } from "../screens/Home";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { CriarCarteirinha } from "../screens/CriarCarteirinha";

const { Navigator, Screen } = createNativeStackNavigator();

export function AppRoutes() {
  return (
    <Navigator screenOptions={{ headerShown: false }}>
      <Screen name="home" component={Home} />
      <Screen name="carteirinha" component={Carteirinha} />
      <Screen name="criarcarteirinha" component={CriarCarteirinha} />
    </Navigator>
  );
}
